﻿INSERT INTO ndc_core.booking_refs (booking_ref,order_id,order_owner,sender_id) VALUES (
'P2LNZ','D12348C68','7I','35200421');
INSERT INTO ndc_core.booking_refs (booking_ref,order_id,order_owner,sender_id) VALUES (
'P2LP1','D12348C78','7I','35200421');
INSERT INTO ndc_core.booking_refs (booking_ref,order_id,order_owner,sender_id) VALUES (
'P2LPK','D12348CF8','7I','35200421');
INSERT INTO ndc_core.booking_refs (booking_ref,order_id,order_owner,sender_id) VALUES (
'P2LPE','D12348CE8','7I','35200421');
INSERT INTO ndc_core.booking_refs (booking_ref,order_id,order_owner,sender_id) VALUES (
'P2LP4','D12348C98','7I','35200421');
INSERT INTO ndc_core.booking_refs (booking_ref,order_id,order_owner,sender_id) VALUES (
'P2LP3','D12348C88','7I','35200421');
INSERT INTO ndc_core.booking_refs (booking_ref,order_id,order_owner,sender_id) VALUES (
'P2LP6','D12348CB8','7I','35200421');
INSERT INTO ndc_core.booking_refs (booking_ref,order_id,order_owner,sender_id) VALUES (
'P2LPL','D12348CG8','7I','35200421');
