﻿INSERT INTO ndc_core.price_class (price_class_id,cabin_class,cabin_code,class_code,class_name,fare_basis,fare_class) VALUES (
'7I882771092','E_ECONOMY_FLEXIBLE',NULL,NULL,'E_ECONOMY_FLEXIBLE','Y','Y');
INSERT INTO ndc_core.price_class (price_class_id,cabin_class,cabin_code,class_code,class_name,fare_basis,fare_class) VALUES (
'7I-842474440','E_ECONOMY',NULL,NULL,'E_ECONOMY','L','L');
