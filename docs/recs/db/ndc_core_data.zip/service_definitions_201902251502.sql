﻿INSERT INTO ndc_core.service_definitions (service_definition_id,owner,description,name,seat_characteristics,"type") VALUES (
'SVC00040','7I','You can carry 3rd bag per person up to 23 kg, for an extra fee. Items of baggage that are heavier than 23Kg and up to 32kg will be carried as excess baggage for a flat fee of USD 40.','Third Bag',NULL,'BG3');
INSERT INTO ndc_core.service_definitions (service_definition_id,owner,description,name,seat_characteristics,"type") VALUES (
'SVC00039','7I','You can carry 2nd bag per person up to 23 kg, for an extra fee. Items of baggage that are heavier than 23Kg and up to 32kg will be carried as excess baggage for a flat fee of USD 40.','Second Bag',NULL,'BG2');
INSERT INTO ndc_core.service_definitions (service_definition_id,owner,description,name,seat_characteristics,"type") VALUES (
'SVC00059','7I','Your preferred seat can be booked at any time prior to your flight.','Seat Selection',NULL,'ST');
INSERT INTO ndc_core.service_definitions (service_definition_id,owner,description,name,seat_characteristics,"type") VALUES (
'SVC00038','7I','You can carry one bag per person of up to 23Kg, for free. Items of baggage that are heavier than 23Kg and up to 32kg will be carried as excess baggage for a flat fee of USD 40.','Free Bag',NULL,'BG');
