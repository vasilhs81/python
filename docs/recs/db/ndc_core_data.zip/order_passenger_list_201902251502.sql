﻿INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348CF8','11292037825917650',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348C98','11292037825917650',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348CE8','11292037825917650',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348CE8','113782449782183',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348C78','11292037825917650',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348C78','171648616279855',2,false,false);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348CG8','11292037825917650',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348CG8','113782449782183',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348CB8','127800580260813',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348CB8','1775593559674963',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348C68','11292037825917650',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348C68','171023018621550',2,false,false);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348C88','11292037825917650',1,false,true);
INSERT INTO ndc_core.order_passenger_list (order_id,passenger_ref,seq_num,payer_ind,primary_ind) VALUES (
'D12348C88','172541141870207',2,false,false);
