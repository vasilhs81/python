﻿INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-dd3351d784374284aad63bbe34f52f86','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-dd3351d784374284aad63bbe34f52f86','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-dd3351d784374284aad63bbe34f52f86','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-7c91e315d8224aa7a404cd7633493254','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-7c91e315d8224aa7a404cd7633493254','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-7c91e315d8224aa7a404cd7633493254','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-0ac6938575ee460f83fc03eb952b0ba7','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-0ac6938575ee460f83fc03eb952b0ba7','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-0ac6938575ee460f83fc03eb952b0ba7','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-cc4998d8b7394646a98bea4d93e679c7','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-cc4998d8b7394646a98bea4d93e679c7','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-cc4998d8b7394646a98bea4d93e679c7','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-bab6128d421645adb1a7338eee6087e1','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-bab6128d421645adb1a7338eee6087e1','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-bab6128d421645adb1a7338eee6087e1','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6296a3f38ded488d9ec12f579b84d377','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6296a3f38ded488d9ec12f579b84d377','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6296a3f38ded488d9ec12f579b84d377','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-8b43e5f8d8fb48999976cb8cfe2d700c','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-8b43e5f8d8fb48999976cb8cfe2d700c','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-8b43e5f8d8fb48999976cb8cfe2d700c','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-2e931b855e9642569d6f2c5237c4817f','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-2e931b855e9642569d6f2c5237c4817f','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-2e931b855e9642569d6f2c5237c4817f','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-bb709db07a6e4d71866c80e052e7444f','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-bb709db07a6e4d71866c80e052e7444f','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-bb709db07a6e4d71866c80e052e7444f','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-9b0201e33b1943d6bb3f2b2864b32d18','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-9b0201e33b1943d6bb3f2b2864b32d18','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-9b0201e33b1943d6bb3f2b2864b32d18','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-7538d45a4d39434dac53438ef8cd54ae','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-7538d45a4d39434dac53438ef8cd54ae','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-7538d45a4d39434dac53438ef8cd54ae','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-27ee8bb4fb4c4a4d9e5ea1659f90f23a','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-d11c69bfebe54661b1a20f31e5568036','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-d11c69bfebe54661b1a20f31e5568036','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-d11c69bfebe54661b1a20f31e5568036','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-21cd30c795bf438c99a8b229d7146fb3','11292037825917650','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-21cd30c795bf438c99a8b229d7146fb3','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6af6213f55914bd98980827e6868fbf6','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6af6213f55914bd98980827e6868fbf6','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6af6213f55914bd98980827e6868fbf6','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-b2f255434f924d9eaa7c1d88ae3ecf15','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-b2f255434f924d9eaa7c1d88ae3ecf15','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-b2f255434f924d9eaa7c1d88ae3ecf15','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-0b547145a318494bbb674701dbf7ebbb','11292037825917650','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-0b547145a318494bbb674701dbf7ebbb','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-16610249fdde437e8f8400ca544a37a5','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-14af9e16873246bea1d6172da39260b4','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-14af9e16873246bea1d6172da39260b4','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-14af9e16873246bea1d6172da39260b4','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-f0f4abf3f9694550a903b5fb60adab26','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-f0f4abf3f9694550a903b5fb60adab26','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-f0f4abf3f9694550a903b5fb60adab26','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-9a3eab4bd9f0496aa31660e5a5db6a34','11292037825917650','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-9a3eab4bd9f0496aa31660e5a5db6a34','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6b2f64258425435bb586af09afd63729','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6b2f64258425435bb586af09afd63729','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6b2f64258425435bb586af09afd63729','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-c31523daf551450ab173b74d563c532b','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-c31523daf551450ab173b74d563c532b','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-c31523daf551450ab173b74d563c532b','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-fecaa8d70b6c432082022e2c6df6d268','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-fecaa8d70b6c432082022e2c6df6d268','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-fecaa8d70b6c432082022e2c6df6d268','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-f9fa4242bda248958ebefbea3a9a9f5a','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-f9fa4242bda248958ebefbea3a9a9f5a','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-f9fa4242bda248958ebefbea3a9a9f5a','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-c9bbf9eb4bb240a0a32194d72d08f8c0','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-9b96dcf2a4404466ab826ff8339e4a16','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-9b96dcf2a4404466ab826ff8339e4a16','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-9b96dcf2a4404466ab826ff8339e4a16','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-348bb14ac63c4f5c981c9f2d293f409f','11292037825917650','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-348bb14ac63c4f5c981c9f2d293f409f','171023018621550','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-348bb14ac63c4f5c981c9f2d293f409f','SH1','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-348bb14ac63c4f5c981c9f2d293f409f','SH2','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e91f269009c54baa8c48d54160b53c7b','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e91f269009c54baa8c48d54160b53c7b','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e91f269009c54baa8c48d54160b53c7b','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-1887667dbba9425290ced1e5d882fd11','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-1887667dbba9425290ced1e5d882fd11','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-1887667dbba9425290ced1e5d882fd11','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-5aa77d3747b04f709783fad1118ba6fb','172541141870207','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-5aa77d3747b04f709783fad1118ba6fb','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-132f7237af9e488092b66623a16d1eb1','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-132f7237af9e488092b66623a16d1eb1','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-132f7237af9e488092b66623a16d1eb1','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-c628eb0653044a80895fe3250dfc8ce6','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-c628eb0653044a80895fe3250dfc8ce6','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-c628eb0653044a80895fe3250dfc8ce6','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-b7e2e2c3a7344ef1a6e5d791290a74d9','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-b7e2e2c3a7344ef1a6e5d791290a74d9','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-b7e2e2c3a7344ef1a6e5d791290a74d9','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-63f084455d824ab69b52bec072409f7b','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-63f084455d824ab69b52bec072409f7b','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-63f084455d824ab69b52bec072409f7b','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-dfcaaae3913942588b474145d3f6803f','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-dfcaaae3913942588b474145d3f6803f','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-dfcaaae3913942588b474145d3f6803f','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-c367a94421244eb6a2235420345a2d6c','171648616279855','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-c367a94421244eb6a2235420345a2d6c','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e1d1d29c1b1e4271b98d6e66cb7a25d0','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e1d1d29c1b1e4271b98d6e66cb7a25d0','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e1d1d29c1b1e4271b98d6e66cb7a25d0','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-eaab083571304125b9f75e06951c4922','1775593559674963','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-eaab083571304125b9f75e06951c4922','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e3dbf5c1260f4ef4b715956e94bd2b67','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-926eeeb8b0c84b22bedcc9826ecac4bb','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-926eeeb8b0c84b22bedcc9826ecac4bb','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-926eeeb8b0c84b22bedcc9826ecac4bb','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-afd3f883a014419c8a2b488e9a98e38c','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-afd3f883a014419c8a2b488e9a98e38c','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-afd3f883a014419c8a2b488e9a98e38c','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6683d74b67c248a78e0837edc731c581','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6683d74b67c248a78e0837edc731c581','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-d1eecf861a504abdab8b408229703b7e','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-d1eecf861a504abdab8b408229703b7e','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-d1eecf861a504abdab8b408229703b7e','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-086225b629cd4fa087b2090a3f83068e','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-086225b629cd4fa087b2090a3f83068e','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-086225b629cd4fa087b2090a3f83068e','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e530a3cc19894700bcc83bdf91e836d3','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e530a3cc19894700bcc83bdf91e836d3','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-a8f91cd34e4d443998d7b5fb9f7364c7','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-a8f91cd34e4d443998d7b5fb9f7364c7','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-a8f91cd34e4d443998d7b5fb9f7364c7','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-37806ac267634ec6b067a6b8019df200','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-37806ac267634ec6b067a6b8019df200','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-4f416df03e6a4e8fb38323ad9dd2417c','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-4f416df03e6a4e8fb38323ad9dd2417c','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-4f416df03e6a4e8fb38323ad9dd2417c','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-1baa75e78c8e4d8f915687b527ff0cde','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-1baa75e78c8e4d8f915687b527ff0cde','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-1baa75e78c8e4d8f915687b527ff0cde','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-226cd983da834c4596887759dfa2804b','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-226cd983da834c4596887759dfa2804b','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-226cd983da834c4596887759dfa2804b','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-3ef8340ce049437997fe22a1b4a7731e','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-3ef8340ce049437997fe22a1b4a7731e','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-3ef8340ce049437997fe22a1b4a7731e','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-c0275556c86c460da436baffc6574b4c','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-c0275556c86c460da436baffc6574b4c','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-c0275556c86c460da436baffc6574b4c','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-45d940d2c08e400eabd2e64d8a20b577','1775593559674963','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'107-45d940d2c08e400eabd2e64d8a20b577','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-887b6c18f266441b994ba55959e8bf9a','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-f4c22f918ffc4ef4bd18546f561b5d16','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-f4c22f918ffc4ef4bd18546f561b5d16','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-f4c22f918ffc4ef4bd18546f561b5d16','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e5cd33c56cf64946b4789505dbdfffec','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e5cd33c56cf64946b4789505dbdfffec','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-e5cd33c56cf64946b4789505dbdfffec','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-32d96b4ebf544c59b8c04eaf400d6453','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-32d96b4ebf544c59b8c04eaf400d6453','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-32d96b4ebf544c59b8c04eaf400d6453','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6cc65c9dc3ce4cb596c8d74e9c1beb32','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6cc65c9dc3ce4cb596c8d74e9c1beb32','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-6cc65c9dc3ce4cb596c8d74e9c1beb32','SH3','INF');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-a6316c57e35d4dd684bb38e69480d15b','SH1','ADT');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-a6316c57e35d4dd684bb38e69480d15b','SH2','CNN');
INSERT INTO ndc_core.passengers_shopping_rs (response_id,pax_id,ptc) VALUES (
'201-a6316c57e35d4dd684bb38e69480d15b','SH3','INF');
