﻿INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'service_categories','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'service_packs','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'discounts','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'bundles','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'points_of_sale','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'services','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'marketing_messages','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'insights','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'flights','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'audit_log','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'rule_sets','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'rich_content','default','euro',true);
INSERT INTO rcms.system_settings (component,colortheme,currency,enabled) VALUES (
'media_library','default','euro',true);
