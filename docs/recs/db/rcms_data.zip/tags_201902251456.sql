﻿INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'ADT','','ADT');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'fle','x','flex');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'fle','xible','Flexible');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'boo','king date','booking date');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'boo','king day','booking day');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'fli','ghtgroup','FlightGroup');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'tag','1','tag1');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'tag','bill1 tagbill2 tagbill3','TagBill1 TagBill2 TagBill3');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'cur',' sxm','CUR SXM');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'INF','','INF');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'car','ribean','Carribean');
INSERT INTO rcms.tags (tag_prefix,tag_remaining,tag) VALUES (
'ptc','','ptc');
