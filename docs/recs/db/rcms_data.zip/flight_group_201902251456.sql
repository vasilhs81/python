﻿INSERT INTO rcms.flight_group (id,flight_id,destination,flight_name,name,origin,status,tags,version) VALUES (
'FG00001','FL00045','SXM','511','Bill FlightGroup1 CUR-SXM','CUR',NULL,NULL,d84ef79d-e93f-47a9-8919-7850ecc70b12);
INSERT INTO rcms.flight_group (id,flight_id,destination,flight_name,name,origin,status,tags,version) VALUES (
'FG00012','FL00035','CUR','7I402','Aruba to St Maarten','AUA',NULL,NULL,07778bf8-6315-46bf-92cd-4eee897074b8);
INSERT INTO rcms.flight_group (id,flight_id,destination,flight_name,name,origin,status,tags,version) VALUES (
'FG00012','FL00044','SXM','7I511','Aruba to St Maarten','CUR',NULL,NULL,07778bf8-6315-46bf-92cd-4eee897074b8);
INSERT INTO rcms.flight_group (id,flight_id,destination,flight_name,name,origin,status,tags,version) VALUES (
'FG00013','FL00049','CUR','161','Test FG','AUA',NULL,[tag1],2897b4b2-915e-40b0-b615-11ab4ba56200);
