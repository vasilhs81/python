﻿INSERT INTO rcms.languages (code,id) VALUES (
'ru','Russian');
INSERT INTO rcms.languages (code,id) VALUES (
'mt','Maltese');
INSERT INTO rcms.languages (code,id) VALUES (
'ur','Urdu');
INSERT INTO rcms.languages (code,id) VALUES (
'bm','Bambara');
INSERT INTO rcms.languages (code,id) VALUES (
'es','Spanish; Castilian');
INSERT INTO rcms.languages (code,id) VALUES (
'sd','Sindhi');
INSERT INTO rcms.languages (code,id) VALUES (
'nb','Norwegian Bokmål');
INSERT INTO rcms.languages (code,id) VALUES (
'gd','Scottish Gaelic; Gaelic');
INSERT INTO rcms.languages (code,id) VALUES (
'st','Southern Sotho');
INSERT INTO rcms.languages (code,id) VALUES (
'ml','Malayalam');
INSERT INTO rcms.languages (code,id) VALUES (
'ab','Abkhaz');
INSERT INTO rcms.languages (code,id) VALUES (
'kn','Kannada');
INSERT INTO rcms.languages (code,id) VALUES (
'ja','Japanese');
INSERT INTO rcms.languages (code,id) VALUES (
'kg','Kongo');
INSERT INTO rcms.languages (code,id) VALUES (
'pl','Polish');
INSERT INTO rcms.languages (code,id) VALUES (
'sg','Sango');
INSERT INTO rcms.languages (code,id) VALUES (
'io','Ido');
INSERT INTO rcms.languages (code,id) VALUES (
'sm','Samoan');
INSERT INTO rcms.languages (code,id) VALUES (
'ia','Interlingua');
INSERT INTO rcms.languages (code,id) VALUES (
'kv','Komi');
INSERT INTO rcms.languages (code,id) VALUES (
'ho','Hiri Motu');
INSERT INTO rcms.languages (code,id) VALUES (
'kr','Kanuri');
INSERT INTO rcms.languages (code,id) VALUES (
'uz','Uzbek');
INSERT INTO rcms.languages (code,id) VALUES (
'an','Aragonese');
INSERT INTO rcms.languages (code,id) VALUES (
'bh','Bihari');
INSERT INTO rcms.languages (code,id) VALUES (
'mk','Macedonian');
INSERT INTO rcms.languages (code,id) VALUES (
'tl','Tagalog');
INSERT INTO rcms.languages (code,id) VALUES (
'cy','Welsh');
INSERT INTO rcms.languages (code,id) VALUES (
'wa','Walloon');
INSERT INTO rcms.languages (code,id) VALUES (
'qu','Quechua');
INSERT INTO rcms.languages (code,id) VALUES (
'is','Icelandic');
INSERT INTO rcms.languages (code,id) VALUES (
'sq','Albanian');
INSERT INTO rcms.languages (code,id) VALUES (
'li','Limburgish, Limburgan, Limburger');
INSERT INTO rcms.languages (code,id) VALUES (
'aa','Afar');
INSERT INTO rcms.languages (code,id) VALUES (
'to','Tonga (Tonga Islands)');
INSERT INTO rcms.languages (code,id) VALUES (
'eu','Basque');
INSERT INTO rcms.languages (code,id) VALUES (
'ee','Ewe');
INSERT INTO rcms.languages (code,id) VALUES (
'mn','Mongolian');
INSERT INTO rcms.languages (code,id) VALUES (
'zh','Chinese');
INSERT INTO rcms.languages (code,id) VALUES (
'ie','Interlingue');
INSERT INTO rcms.languages (code,id) VALUES (
'pi','Pāli');
INSERT INTO rcms.languages (code,id) VALUES (
'ne','Nepali');
INSERT INTO rcms.languages (code,id) VALUES (
'os','Ossetian, Ossetic');
INSERT INTO rcms.languages (code,id) VALUES (
'gn','Guaraní');
INSERT INTO rcms.languages (code,id) VALUES (
'nl','Dutch');
INSERT INTO rcms.languages (code,id) VALUES (
'yi','Yiddish');
INSERT INTO rcms.languages (code,id) VALUES (
'mh','Marshallese');
INSERT INTO rcms.languages (code,id) VALUES (
'so','Somali');
INSERT INTO rcms.languages (code,id) VALUES (
'as','Assamese');
INSERT INTO rcms.languages (code,id) VALUES (
'ay','Aymara');
INSERT INTO rcms.languages (code,id) VALUES (
'nn','Norwegian Nynorsk');
INSERT INTO rcms.languages (code,id) VALUES (
'vi','Vietnamese');
INSERT INTO rcms.languages (code,id) VALUES (
'he','Hebrew (modern)');
INSERT INTO rcms.languages (code,id) VALUES (
'tr','Turkish');
INSERT INTO rcms.languages (code,id) VALUES (
'om','Oromo');
INSERT INTO rcms.languages (code,id) VALUES (
'pt','Portuguese');
INSERT INTO rcms.languages (code,id) VALUES (
'ce','Chechen');
INSERT INTO rcms.languages (code,id) VALUES (
'en','English');
INSERT INTO rcms.languages (code,id) VALUES (
'xh','Xhosa');
INSERT INTO rcms.languages (code,id) VALUES (
'bs','Bosnian');
INSERT INTO rcms.languages (code,id) VALUES (
'ti','Tigrinya');
INSERT INTO rcms.languages (code,id) VALUES (
'sk','Slovak');
INSERT INTO rcms.languages (code,id) VALUES (
'rm','Romansh');
INSERT INTO rcms.languages (code,id) VALUES (
'nv','Navajo, Navaho');
INSERT INTO rcms.languages (code,id) VALUES (
'nd','North Ndebele');
INSERT INTO rcms.languages (code,id) VALUES (
'ak','Akan');
INSERT INTO rcms.languages (code,id) VALUES (
'it','Italian');
INSERT INTO rcms.languages (code,id) VALUES (
'sr','Serbian');
INSERT INTO rcms.languages (code,id) VALUES (
'am','Amharic');
INSERT INTO rcms.languages (code,id) VALUES (
'ca','Catalan; Valencian');
INSERT INTO rcms.languages (code,id) VALUES (
'da','Danish');
INSERT INTO rcms.languages (code,id) VALUES (
'lv','Latvian');
INSERT INTO rcms.languages (code,id) VALUES (
'nr','South Ndebele');
INSERT INTO rcms.languages (code,id) VALUES (
'id','Indonesian');
INSERT INTO rcms.languages (code,id) VALUES (
'mg','Malagasy');
INSERT INTO rcms.languages (code,id) VALUES (
'ug','Uighur, Uyghur');
INSERT INTO rcms.languages (code,id) VALUES (
'de','German');
INSERT INTO rcms.languages (code,id) VALUES (
'br','Breton');
INSERT INTO rcms.languages (code,id) VALUES (
'ht','Haitian; Haitian Creole');
INSERT INTO rcms.languages (code,id) VALUES (
'bi','Bislama');
INSERT INTO rcms.languages (code,id) VALUES (
'ha','Hausa');
INSERT INTO rcms.languages (code,id) VALUES (
'co','Corsican');
INSERT INTO rcms.languages (code,id) VALUES (
'hy','Armenian');
INSERT INTO rcms.languages (code,id) VALUES (
'ba','Bashkir');
INSERT INTO rcms.languages (code,id) VALUES (
'hr','Croatian');
INSERT INTO rcms.languages (code,id) VALUES (
'wo','Wolof');
INSERT INTO rcms.languages (code,id) VALUES (
'oj','Ojibwe, Ojibwa');
INSERT INTO rcms.languages (code,id) VALUES (
'be','Belarusian');
INSERT INTO rcms.languages (code,id) VALUES (
'jv','Javanese');
INSERT INTO rcms.languages (code,id) VALUES (
'yo','Yoruba');
INSERT INTO rcms.languages (code,id) VALUES (
'lg','Luganda');
INSERT INTO rcms.languages (code,id) VALUES (
'oc','Occitan');
INSERT INTO rcms.languages (code,id) VALUES (
'hz','Herero');
INSERT INTO rcms.languages (code,id) VALUES (
'tw','Twi');
INSERT INTO rcms.languages (code,id) VALUES (
'tt','Tatar');
INSERT INTO rcms.languages (code,id) VALUES (
'ig','Igbo');
INSERT INTO rcms.languages (code,id) VALUES (
'th','Thai');
INSERT INTO rcms.languages (code,id) VALUES (
'fo','Faroese');
INSERT INTO rcms.languages (code,id) VALUES (
'bg','Bulgarian');
INSERT INTO rcms.languages (code,id) VALUES (
'bn','Bengali');
INSERT INTO rcms.languages (code,id) VALUES (
'cs','Czech');
INSERT INTO rcms.languages (code,id) VALUES (
'tn','Tswana');
INSERT INTO rcms.languages (code,id) VALUES (
'ga','Irish');
INSERT INTO rcms.languages (code,id) VALUES (
'ro','Romanian, Moldavian, Moldovan');
INSERT INTO rcms.languages (code,id) VALUES (
'my','Burmese');
INSERT INTO rcms.languages (code,id) VALUES (
'ta','Tamil');
INSERT INTO rcms.languages (code,id) VALUES (
'tg','Tajik');
INSERT INTO rcms.languages (code,id) VALUES (
'na','Nauru');
INSERT INTO rcms.languages (code,id) VALUES (
'kl','Kalaallisut, Greenlandic');
INSERT INTO rcms.languages (code,id) VALUES (
'mi','Māori');
INSERT INTO rcms.languages (code,id) VALUES (
'ii','Nuosu');
INSERT INTO rcms.languages (code,id) VALUES (
'sc','Sardinian');
INSERT INTO rcms.languages (code,id) VALUES (
'dv','Divehi; Dhivehi; Maldivian;');
INSERT INTO rcms.languages (code,id) VALUES (
'fa','Persian');
INSERT INTO rcms.languages (code,id) VALUES (
'bo','Tibetan Standard, Tibetan, Central');
INSERT INTO rcms.languages (code,id) VALUES (
'ks','Kashmiri');
INSERT INTO rcms.languages (code,id) VALUES (
'la','Latin');
INSERT INTO rcms.languages (code,id) VALUES (
'no','Norwegian');
INSERT INTO rcms.languages (code,id) VALUES (
'ki','Kikuyu, Gikuyu');
INSERT INTO rcms.languages (code,id) VALUES (
'za','Zhuang, Chuang');
INSERT INTO rcms.languages (code,id) VALUES (
'pa','Panjabi, Punjabi');
INSERT INTO rcms.languages (code,id) VALUES (
'sv','Swedish');
INSERT INTO rcms.languages (code,id) VALUES (
'fj','Fijian');
INSERT INTO rcms.languages (code,id) VALUES (
'af','Afrikaans');
INSERT INTO rcms.languages (code,id) VALUES (
'fy','Western Frisian');
INSERT INTO rcms.languages (code,id) VALUES (
'ps','Pashto, Pushto');
INSERT INTO rcms.languages (code,id) VALUES (
'km','Khmer');
INSERT INTO rcms.languages (code,id) VALUES (
'ff','Fula; Fulah; Pulaar; Pular');
INSERT INTO rcms.languages (code,id) VALUES (
'kw','Cornish');
INSERT INTO rcms.languages (code,id) VALUES (
'lt','Lithuanian');
INSERT INTO rcms.languages (code,id) VALUES (
'cv','Chuvash');
INSERT INTO rcms.languages (code,id) VALUES (
'tk','Turkmen');
INSERT INTO rcms.languages (code,id) VALUES (
'or','Oriya');
INSERT INTO rcms.languages (code,id) VALUES (
'sn','Shona');
INSERT INTO rcms.languages (code,id) VALUES (
'lb','Luxembourgish, Letzeburgesch');
INSERT INTO rcms.languages (code,id) VALUES (
'sw','Swahili');
INSERT INTO rcms.languages (code,id) VALUES (
'fi','Finnish');
INSERT INTO rcms.languages (code,id) VALUES (
'ku','Kurdish');
INSERT INTO rcms.languages (code,id) VALUES (
'ik','Inupiaq');
INSERT INTO rcms.languages (code,id) VALUES (
'hu','Hungarian');
INSERT INTO rcms.languages (code,id) VALUES (
'ln','Lingala');
INSERT INTO rcms.languages (code,id) VALUES (
'rw','Kinyarwanda');
INSERT INTO rcms.languages (code,id) VALUES (
'cu','Old Church Slavonic, Church Slavic, Church Slavonic, Old Bulgarian, Old Slavonic');
INSERT INTO rcms.languages (code,id) VALUES (
'sa','Sanskrit (Saṁskṛta)');
INSERT INTO rcms.languages (code,id) VALUES (
'gl','Galician');
INSERT INTO rcms.languages (code,id) VALUES (
'kk','Kazakh');
INSERT INTO rcms.languages (code,id) VALUES (
'ko','Korean');
INSERT INTO rcms.languages (code,id) VALUES (
'kj','Kwanyama, Kuanyama');
INSERT INTO rcms.languages (code,id) VALUES (
'fr','French');
INSERT INTO rcms.languages (code,id) VALUES (
'az','Azerbaijani');
INSERT INTO rcms.languages (code,id) VALUES (
'et','Estonian');
INSERT INTO rcms.languages (code,id) VALUES (
'te','Telugu');
INSERT INTO rcms.languages (code,id) VALUES (
'hi','Hindi');
INSERT INTO rcms.languages (code,id) VALUES (
'ae','Avestan');
INSERT INTO rcms.languages (code,id) VALUES (
'rn','Kirundi');
INSERT INTO rcms.languages (code,id) VALUES (
'iu','Inuktitut');
INSERT INTO rcms.languages (code,id) VALUES (
'ts','Tsonga');
INSERT INTO rcms.languages (code,id) VALUES (
'uk','Ukrainian');
INSERT INTO rcms.languages (code,id) VALUES (
'mr','Marathi (Marāṭhī)');
INSERT INTO rcms.languages (code,id) VALUES (
'cr','Cree');
INSERT INTO rcms.languages (code,id) VALUES (
'vo','Volapük');
INSERT INTO rcms.languages (code,id) VALUES (
'ng','Ndonga');
INSERT INTO rcms.languages (code,id) VALUES (
'el','Greek, Modern');
INSERT INTO rcms.languages (code,id) VALUES (
'ny','Chichewa; Chewa; Nyanja');
INSERT INTO rcms.languages (code,id) VALUES (
'gu','Gujarati');
INSERT INTO rcms.languages (code,id) VALUES (
'eo','Esperanto');
INSERT INTO rcms.languages (code,id) VALUES (
'lo','Lao');
INSERT INTO rcms.languages (code,id) VALUES (
'av','Avaric');
INSERT INTO rcms.languages (code,id) VALUES (
've','Venda');
INSERT INTO rcms.languages (code,id) VALUES (
'ar','Arabic');
INSERT INTO rcms.languages (code,id) VALUES (
'su','Sundanese');
INSERT INTO rcms.languages (code,id) VALUES (
'ky','Kirghiz, Kyrgyz');
INSERT INTO rcms.languages (code,id) VALUES (
'ss','Swati');
INSERT INTO rcms.languages (code,id) VALUES (
'se','Northern Sami');
INSERT INTO rcms.languages (code,id) VALUES (
'ka','Georgian');
INSERT INTO rcms.languages (code,id) VALUES (
'ms','Malay');
INSERT INTO rcms.languages (code,id) VALUES (
'ch','Chamorro');
INSERT INTO rcms.languages (code,id) VALUES (
'lu','Luba-Katanga');
INSERT INTO rcms.languages (code,id) VALUES (
'ty','Tahitian');
INSERT INTO rcms.languages (code,id) VALUES (
'gv','Manx');
INSERT INTO rcms.languages (code,id) VALUES (
'si','Slovene');
