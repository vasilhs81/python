﻿INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'VIDEO','MD00014',2017-06-15 16:33:56.000,'YOUTUBE','hERFEBCIuJI',NULL,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'VIDEO','MD00015',2017-06-15 16:39:09.000,'YOUTUBE','VovylZ3lfLc',NULL,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'VIDEO','MD00016',2017-06-15 16:33:56.000,'YOUTUBE','biPuo1ppIZA',0,NULL,2e988ee5-1b51-457d-9a6d-610ed264defa);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'VIDEO','MD00017',2017-06-15 16:33:56.000,'YOUTUBE','eeBrAg0a3wM',0,NULL,a14a859c-9084-431b-a493-38a8625ba241);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00001',2017-07-05 17:01:03.000,'RCMS','02d6b94d-0852-400b-a883-c6fe05d38ee5.jpeg',45820,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00002',2017-06-27 17:35:47.000,'RCMS','c0b7ae2b-d4a5-40f8-86d5-29d9122966ce.jpeg',464110,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00003',2017-06-19 11:34:11.000,'RCMS','2861122f-2c91-45bd-ab1e-36f2150d19e7.jpeg',551378,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00004',2017-06-27 17:36:19.000,'RCMS','e1a008db-6b04-4b20-b63d-fd8cc034c58a.jpeg',310195,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00005',2017-06-27 17:35:48.000,'RCMS','12f9abfd-1017-47fd-9d51-67cefa8ecc06.jpeg',582614,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00006',2017-07-07 12:34:11.000,'RCMS','31237f30-18be-450d-9e80-112be8aab193.jpeg',53137,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00007',2017-07-06 10:35:24.000,'RCMS','c6d4bcb7-b026-4f80-88b1-c0aed4fd2165.jpeg',51339,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00008',2017-06-15 16:33:56.000,'RCMS','c4f42bc9-f47f-453d-bf3b-e0cb6d4e3751.jpeg',14265,NULL,8bbcd421-ae49-4bd0-b5f1-e92197b8438e);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00009',2017-06-27 17:36:19.000,'RCMS','a8d9ecfb-7d49-44ad-a6af-6aea4886e7e4.jpeg',406214,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00010',2017-04-28 22:33:20.000,'RCMS','25963ab0-0f09-4fd3-b2b5-45cdffeff967.jpeg',469173,NULL,425cab30-2fce-41b8-94e0-5645362dfa87);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00011',2017-06-27 17:36:57.000,'RCMS','462f918d-4512-4a60-b086-a29a07743ba2.jpeg',154648,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00012',2017-06-27 17:36:57.000,'RCMS','d8d6fc36-eb1c-46fd-99a1-402a7fdbdd4b.jpeg',303898,NULL,02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.media_by_type ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00013',2017-06-15 16:33:56.000,'RCMS','455394a2-77a7-4a01-acaa-e4163b195bdc.jpeg',53685,NULL,0cdff80b-f58b-4b72-b676-78d32b25d246);
