﻿INSERT INTO rcms.devices (id,code,mandatory) VALUES (
'Airport kiosk','3',false);
INSERT INTO rcms.devices (id,code,mandatory) VALUES (
'Unknown','6',true);
INSERT INTO rcms.devices (id,code,mandatory) VALUES (
'Agent terminal','1',false);
INSERT INTO rcms.devices (id,code,mandatory) VALUES (
'Web browser','2',false);
INSERT INTO rcms.devices (id,code,mandatory) VALUES (
'Mobile device','4',false);
INSERT INTO rcms.devices (id,code,mandatory) VALUES (
'Other','5',false);
