﻿INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'RS','RS00001','ADT');
INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'RS','RS00001','Carribean');
INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'RS','RS00001','INF');
INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'RS','RS00004','CUR SXM');
INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'RS','RS00004','FlightGroup');
INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'RS','RS00002','Flexible');
INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'RS','RS00003','flex');
INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'RS','RS00003','ptc');
INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'RS','RS00005','booking date');
INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'RS','RS00005','booking day');
INSERT INTO rcms.tags_by_entity_prefix (entity_prefix,entity_id,tag) VALUES (
'FG','FG00013','tag1');
