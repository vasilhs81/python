﻿INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC00110','SEAT','Seat Extra Legroom',1e19b35b-7018-486b-97ea-32d7ed853dc9);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC10110','IE','Inflight Entertainment',d97c987e-a0ad-420f-b04e-27612b982e17);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC00111','MLS','Meal Beverage',580c0b10-5428-4911-8d11-ebeb8cedee93);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC10111','ML','Meal',dbaa3123-fadb-4edb-a885-6d1c546e73b3);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC00123','IC','Internet Connection',75dbdd07-238f-4baa-98e5-3994f971bbfb);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC00040','LG','Lounge',02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC10112','CM','Communication',02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC10109','BG','Baggage',02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC00109','BG4','Fourth Bag',e7a104e9-29f9-4cf3-b08a-81168b1737e9);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC00106','ST','Seat',3106aef9-6dc6-49e5-b184-87f15cb5ec48);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC00041','PT','Pets',02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.service_categories_by_id (id,code,name,version) VALUES (
'SC00039','GT','Ground Transportation',02d6b94d-0852-400b-a883-c6fe05d38ee5);
