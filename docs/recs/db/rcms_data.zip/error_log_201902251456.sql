﻿INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-15 16:26:11.429,'ERR00017','Exception in com.jrtechnologies.rcms.web.rest.UserResource.getAllUsers() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.repository.RoleRepository.findAllWithPermissions(RoleRepository.java:110)','UR00003');
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-15 16:25:05.427,'ERR00016','Exception in com.jrtechnologies.rcms.web.rest.UserResource.getAllUsers() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.repository.RoleRepository.findAllWithPermissions(RoleRepository.java:107)','UR00003');
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-15 16:22:25.506,'ERR00015','Exception in com.jrtechnologies.rcms.web.rest.UserResource.getAllUsers() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.repository.RoleRepository.findAllWithPermissions(RoleRepository.java:107)','UR00003');
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-15 16:13:41.566,'ERR00014','Exception in com.jrtechnologies.rcms.web.rest.UserResource.getAllUsers() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.repository.RoleRepository.findAllWithPermissions(RoleRepository.java:107)','UR00003');
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-15 16:13:07.559,'ERR00013','Exception in com.jrtechnologies.rcms.web.rest.UserResource.getAllUsers() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.repository.RoleRepository.findAllWithPermissions(RoleRepository.java:107)','UR00003');
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-15 16:07:45.323,'ERR00012','Exception in com.jrtechnologies.rcms.web.rest.UserResource.getAllUsers() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.repository.RoleRepository.findAllWithPermissions(RoleRepository.java:107)','UR00003');
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-15 15:52:35.311,'ERR00011','Exception in com.jrtechnologies.rcms.web.rest.RoleResource.getRoles() with cause = ''null'' and exception = ''Duplicate key Role{id=RL00003, roleName=''Anonymous'',permissions=''{}''}''','java.util.stream.Collectors.lambda$throwingMerger$0(Collectors.java:133)','UR00003');
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-15 15:52:07.303,'ERR00010','Exception in com.jrtechnologies.rcms.web.rest.UserResource.getAllUsers() with cause = ''null'' and exception = ''Duplicate key Role{id=RL00003, roleName=''Anonymous'',permissions=''{}''}''','java.util.stream.Collectors.lambda$throwingMerger$0(Collectors.java:133)','UR00003');
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-15 15:41:28.247,'ERR00009','Exception in com.jrtechnologies.rcms.web.rest.UserResource.getAllUsers() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.service.mapper.RoleMapper.toVm(RoleMapper.java:102)','UR00003');
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-06 15:47:53.722,'ERR00008','Exception in com.jrtechnologies.rcms.web.rest.UserJWTController.authorize() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.service.mapper.RoleMapper.toDto(RoleMapper.java:41)',NULL);
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-06 15:46:38.196,'ERR00007','Exception in com.jrtechnologies.rcms.web.rest.UserJWTController.authorize() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.service.mapper.RoleMapper.toDto(RoleMapper.java:41)',NULL);
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-06 15:42:36.631,'ERR00006','Exception in com.jrtechnologies.rcms.web.rest.UserJWTController.authorize() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.service.mapper.RoleMapper.toDto(RoleMapper.java:41)',NULL);
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-06 15:39:45.647,'ERR00005','Exception in com.jrtechnologies.rcms.web.rest.UserJWTController.authorize() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.service.mapper.RoleMapper.toDto(RoleMapper.java:41)',NULL);
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-06 15:39:28.961,'ERR00004','Exception in com.jrtechnologies.rcms.web.rest.UserJWTController.authorize() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.service.mapper.RoleMapper.toDto(RoleMapper.java:41)',NULL);
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-06 15:39:18.736,'ERR00003','Exception in com.jrtechnologies.rcms.web.rest.UserJWTController.authorize() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.service.mapper.RoleMapper.toDto(RoleMapper.java:41)',NULL);
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-06 15:37:20.091,'ERR00002','Exception in com.jrtechnologies.rcms.web.rest.UserJWTController.authorize() with cause = ''null'' and exception = ''null''','com.jrtechnologies.rcms.service.mapper.RoleMapper.toDto(RoleMapper.java:41)',NULL);
INSERT INTO rcms.error_log ("month","timestamp",id,message,stacktrace,user_id) VALUES (
'FEBRUARY',2019-02-06 15:37:14.985,'ERR00001','Exception in com.jrtechnologies.rcms.web.rest.UserJWTController.authorize() with cause = ''null'' and exception = ''error.userNotFound''','com.jrtechnologies.rcms.web.rest.UserJWTController.authorize(UserJWTController.java:80)',NULL);
