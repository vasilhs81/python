﻿INSERT INTO rcms.price_optimization (id,air_miles_amount,air_miles_type,monetary_amount,monetary_type,name,rule_sets,version) VALUES (
'PO00032',0,'amount',-50.0,'percentage','Seat Selection Discount',[{rule_set_id:'RS00142',name:'Family with CHD - Destination Germany',tags:{'CHD','Family','Germany Frankfurt','INF'}}],8ffb87c5-6fd3-4a2a-afec-af89238d8c6b);
INSERT INTO rcms.price_optimization (id,air_miles_amount,air_miles_type,monetary_amount,monetary_type,name,rule_sets,version) VALUES (
'PO00029',0,'amount',10.0,'amount','Fri&Sun Markup',[{rule_set_id:'RS00134',name:'FriSun Markup',tags:{'Early Morning','Price Optimization'}}],c9ab67ca-713a-4b51-b83c-d308a7978a94);
INSERT INTO rcms.price_optimization (id,air_miles_amount,air_miles_type,monetary_amount,monetary_type,name,rule_sets,version) VALUES (
'PO00031',0,'amount',-50.0,'percentage','Family Meal 50% Discount',[{rule_set_id:'RS00136',name:'Inselair_ADTwithCHD',tags:{'ADTwithCHD','Price Optimization'}}],1d4efe8c-fe45-4f28-9948-1c7681026180);
INSERT INTO rcms.price_optimization (id,air_miles_amount,air_miles_type,monetary_amount,monetary_type,name,rule_sets,version) VALUES (
'PO00028',0,'amount',-10.0,'amount','Mid-Week Discount except Sat',[{rule_set_id:'RS00133',name:'Mid-Week Discount',tags:{'Price Optimization','not Friday','not Sunday'}}],3180eacd-f410-4f6a-8d9f-b893245c2e58);
INSERT INTO rcms.price_optimization (id,air_miles_amount,air_miles_type,monetary_amount,monetary_type,name,rule_sets,version) VALUES (
'PO00034',0,'percentage',-50.0,'percentage','Inselair 2nd bag ADT with INF -50% 11-28/02',[{rule_set_id:'RS00151',name:'ADT with INF 11-28/02',tags:{'ADT','INF','Time Period'}}],aa69650f-546d-4d21-8b95-d5fe3294c69a);
INSERT INTO rcms.price_optimization (id,air_miles_amount,air_miles_type,monetary_amount,monetary_type,name,rule_sets,version) VALUES (
'PO00001',100,'amount',-50.0,'percentage','Bill Opt',[{rule_set_id:'RS00004',name:'Bill Flight RBD Rule',tags:{'CUR SXM','FlightGroup'}}],64a90b70-9e76-4d5a-af27-0148e222c132);
INSERT INTO rcms.price_optimization (id,air_miles_amount,air_miles_type,monetary_amount,monetary_type,name,rule_sets,version) VALUES (
'PO00033',0,'amount',15.0,'percentage','1st Bag ATH-FRA',[{rule_set_id:'RS00146',name:'Economy ATH-FRA',tags:{'ATH','Economy','FRA'}}],3c013d83-928b-46b8-92a3-36d087117f0b);
INSERT INTO rcms.price_optimization (id,air_miles_amount,air_miles_type,monetary_amount,monetary_type,name,rule_sets,version) VALUES (
'PO00030',0,'amount',-10.0,'amount','2nd Baggage Inselair CUR-AUA',[{rule_set_id:'RS00135',name:'CUR-AUA',tags:{'CURAUA','Price Optimization'}}],a22dec7e-f3d3-4ac0-ba0b-b8b3c0ea13fb);
