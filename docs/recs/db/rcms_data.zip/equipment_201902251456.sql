﻿INSERT INTO rcms.equipment (aircraft_type,aircraft_configuration,airline_equipment_code,equipment_id,version) VALUES (
'F27M050','F50','F50','EQ00009',a27b5d4b-7358-4e11-bda1-7fc776161777);
INSERT INTO rcms.equipment (aircraft_type,aircraft_configuration,airline_equipment_code,equipment_id,version) VALUES (
'773','773','773','EQ00014',483264ac-76ba-4a53-8890-3d45c7fc6c72);
INSERT INTO rcms.equipment (aircraft_type,aircraft_configuration,airline_equipment_code,equipment_id,version) VALUES (
'772','772','772','EQ00013',490961fe-cf7a-422f-b115-4ac485bca577);
INSERT INTO rcms.equipment (aircraft_type,aircraft_configuration,airline_equipment_code,equipment_id,version) VALUES (
'738','738','738','EQ00011',45f61ef3-7875-4a73-b09e-7c4d84f4d457);
INSERT INTO rcms.equipment (aircraft_type,aircraft_configuration,airline_equipment_code,equipment_id,version) VALUES (
'320','320','320','EQ00010',442f0a94-094a-47a4-9cda-f55ffcd76201);
INSERT INTO rcms.equipment (aircraft_type,aircraft_configuration,airline_equipment_code,equipment_id,version) VALUES (
'A320','212','F20D24M90','EQ00005',e4495605-f654-464a-9fd9-2a76f157f123);
INSERT INTO rcms.equipment (aircraft_type,aircraft_configuration,airline_equipment_code,equipment_id,version) VALUES (
'76P','76P','76P','EQ00012',75d2c5a0-b8c3-48d3-9d67-8d7287c15600);
INSERT INTO rcms.equipment (aircraft_type,aircraft_configuration,airline_equipment_code,equipment_id,version) VALUES (
'78P','78P','78P','EQ00015',eb73912b-7f1f-4194-8530-6d1e7235e82a);
INSERT INTO rcms.equipment (aircraft_type,aircraft_configuration,airline_equipment_code,equipment_id,version) VALUES (
'A320','111','F12C24M90','EQ00004',9959dc82-6d82-4f6f-894c-84828e27da63);
