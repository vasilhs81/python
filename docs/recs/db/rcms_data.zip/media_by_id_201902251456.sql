﻿INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'VIDEO','MD00014',2017-06-15 22:33:56.000,'YOUTUBE','hERFEBCIuJI',0,NULL,fcab5dc4-a0a3-41be-bacc-53649fa5d708);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'VIDEO','MD00015',2017-06-15 22:39:09.000,'YOUTUBE','VovylZ3lfLc',0,NULL,4fb0f2e6-93e3-4281-bdb5-01efda3c78bb);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'VIDEO','MD00016',2017-06-15 22:39:09.000,'YOUTUBE','biPuo1ppIZA',0,NULL,97d39411-57a0-4df6-9888-2b1e69f09b13);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'VIDEO','MD00017',2017-06-15 22:39:09.000,'YOUTUBE','eeBrAg0a3wM',0,NULL,c6c3431c-42f8-4c19-9db2-c7ea84ab67a8);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00001',2017-07-05 23:01:03.000,'RCMS','02d6b94d-0852-400b-a883-c6fe05d38ee5.jpeg',45820,NULL,b89a8d57-4d9a-4af9-bff3-12ad9bf683f1);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00002',2017-06-27 23:35:47.000,'RCMS','c0b7ae2b-d4a5-40f8-86d5-29d9122966ce.jpeg',464110,NULL,5d069f04-e90d-4a70-a627-736e9ff376b4);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00004',2017-06-27 23:36:19.000,'RCMS','e1a008db-6b04-4b20-b63d-fd8cc034c58a.jpeg',310195,NULL,0a47d555-8655-4d6f-bb21-6fcb63a02346);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00005',2017-06-27 23:35:48.000,'RCMS','12f9abfd-1017-47fd-9d51-67cefa8ecc06.jpeg',582614,NULL,b711913c-4240-41d8-a7c6-71bff5f420b5);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00007',2017-07-06 16:35:24.000,'RCMS','c6d4bcb7-b026-4f80-88b1-c0aed4fd2165.jpeg',51339,NULL,7e35ec2f-5a49-4042-a259-24cf3838f05d);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00008',2017-06-15 22:39:09.000,'RCMS','c4f42bc9-f47f-453d-bf3b-e0cb6d4e3751.jpeg',14265,NULL,df881afe-5aee-4d1f-88b9-97b4a59e5aef);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00010',2017-06-15 22:39:09.000,'RCMS','25963ab0-0f09-4fd3-b2b5-45cdffeff967.jpeg',469173,NULL,f64a1ad2-5070-4be0-a234-6073f98a6438);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00011',2017-06-27 23:36:57.000,'RCMS','462f918d-4512-4a60-b086-a29a07743ba2.jpeg',154648,NULL,ade3f578-98b2-4d2a-815f-f42336996ef5);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00013',2017-06-15 22:39:09.000,'RCMS','455394a2-77a7-4a01-acaa-e4163b195bdc.jpeg',53685,NULL,076b6646-e3e7-4437-a3ea-e40f0496f55a);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00048',2017-08-07 11:56:16.607,'RCMS','b8c005a9-0dcf-4ec0-b4de-4ce80cfecf2d.jpeg',53137,NULL,115639df-8942-4ccd-93ab-4c342a98ed9d);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00070',2017-11-06 17:05:38.805,'RCMS','6c3b3a9c-24c8-46b1-9baf-c6344502f874.jpeg',68435,NULL,6a2bf919-b716-488a-bb84-035cea2feafc);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00071',2017-11-07 11:52:33.781,'RCMS','d1e22cc4-cfb9-41a9-8e0b-f649f6c4ec3c.jpeg',107218,NULL,0440502e-e83b-4ad5-a207-eaca41092d37);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00076',2017-11-14 15:35:51.869,'RCMS','7a689d05-0a16-4226-876e-22f37fcbf8df.jpg',17080,NULL,d5728a5d-ce01-4421-8f23-993dcc0f56bc);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00081',2018-02-08 10:43:53.781,'RCMS','21c1f77f-92aa-4695-a5b4-8d5fc43aa24d.jpg',8398,NULL,d42c2090-869d-4da6-bb69-652a390960a9);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00082',2018-02-12 10:04:16.275,'RCMS','7efa49d6-65f6-4618-a3a5-9d6ce3f97f78.jpg',10750,NULL,1aebb9f4-78e4-45fe-996b-ea86f266b565);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00083',2018-02-12 10:04:30.305,'RCMS','14c387cd-e81f-4c10-8c01-9064c19baa33.jpg',5790,NULL,3c36edf7-e7bb-4db4-b205-3961e52f25d6);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00085',2018-07-06 11:11:29.073,'RCMS','704a8270-7d35-4fe8-8a68-ba252d9d77f5.jpg',57062,NULL,9ec0447d-1c45-48b1-b1c1-9db592f47626);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00086',2018-08-30 18:44:15.285,'RCMS','c043539a-0659-4170-b568-ec8d91d54305.png',188337,NULL,73ea79b5-a543-4ba7-a6f8-1798d523c490);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00087',2018-08-30 18:44:15.243,'RCMS','d5ce8dda-f1f3-4c5b-88ad-299fbacdafc9.png',132244,NULL,4cb57595-97cc-4466-9b54-64ebd173cde6);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00088',2018-08-30 18:44:15.330,'RCMS','74853227-18fd-43cd-9555-022cdb26e2df.png',185683,NULL,fceecf0e-c376-4354-9ec4-fc49c4c9a618);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00089',2018-08-30 18:44:15.312,'RCMS','6e129fe8-01d3-42a0-ae4a-6c9cff543928.png',197031,NULL,34c4ba65-91db-4c7e-8e92-2350a84e4571);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00090',2018-10-10 12:02:52.196,'RCMS','32804003-8464-44fe-9817-eedb47a74bfc.jpg',41138,NULL,6054fe68-6ce1-47ca-94a1-9967b5804abc);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00091',2018-10-31 11:05:34.503,'RCMS','f4e6e11b-def0-41c7-8eb5-1f2f72dff80c.jpg',46164,NULL,245a3d7d-56b1-464e-bf6a-30f44ad2cfe1);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00092',2018-10-31 12:27:02.538,'RCMS','5b3b1a8a-dae6-46db-beab-e8ad1a3b11b7.jpg',9502,NULL,cfc51c65-e7a7-4d3a-8b03-d190cdee01a0);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00093',2018-10-31 12:27:02.762,'RCMS','c3e7e0c3-fe8d-4c46-a731-48eeff15c6a2.jpg',41960,NULL,f1de8619-7d50-4a35-a88e-dfa9f0916e17);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00094',2018-10-31 12:40:08.708,'RCMS','9c8be585-8a23-4181-a9b4-032f4877ecba.jpg',57220,NULL,d2190a9f-5204-46dd-8aa8-137df004cbac);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00095',2018-10-31 12:41:01.941,'RCMS','1b378b3f-ec77-42d1-86d1-ddb0bff5a46b.jpg',57220,NULL,fad6b7c6-542a-4e72-8a5f-2d76ac4b8b65);
INSERT INTO rcms.media_by_id ("type",id,created_at,provider,provider_id,"size",tags,version) VALUES (
'IMAGE','MD00096',2018-10-31 12:41:02.711,'RCMS','633d82a7-9856-4034-9eda-1f8ee0fe52b8.jpg',170011,NULL,ccfe7b4b-0722-4133-9bc0-b6b186735272);
