﻿INSERT INTO rcms.geographical_area (id,airport_code,airport_name,city_code,city_name,country_code,country_name,name,region_code,region_name,version) VALUES (
'GEO00007','ATH','Eleftherios Venizelos','ATH','Athens','GR','Greece','Greece Area','EU','Europe',6e10ae23-8859-49c5-9bcd-a0da2703cd43);
INSERT INTO rcms.geographical_area (id,airport_code,airport_name,city_code,city_name,country_code,country_name,name,region_code,region_name,version) VALUES (
'GEO00009','XXX','All','XXX','All','XXX','All','AUA-CUR','XXX','All',246bb1e9-93ad-48b2-9346-10010c14494c);
INSERT INTO rcms.geographical_area (id,airport_code,airport_name,city_code,city_name,country_code,country_name,name,region_code,region_name,version) VALUES (
'GEO00006','XXX','All','XXX','All','XXX','All','Asia','AS','Asia',22f322f1-3c3d-49ad-ad0a-268815760453);
INSERT INTO rcms.geographical_area (id,airport_code,airport_name,city_code,city_name,country_code,country_name,name,region_code,region_name,version) VALUES (
'GEO00004','XXX','All','XXX','All','XXX','All','Entire World','XXX','All',fc027584-2a2e-4f2c-bfb6-e3586f36630b);
INSERT INTO rcms.geographical_area (id,airport_code,airport_name,city_code,city_name,country_code,country_name,name,region_code,region_name,version) VALUES (
'GEO00008','MIA','Miami International Airport','MIA','Miami','US','United States of America','Inselair AUA-CUR','FL','Florida',7d2d9298-4e91-4e8d-9a0c-e3f3aefe8c86);
INSERT INTO rcms.geographical_area (id,airport_code,airport_name,city_code,city_name,country_code,country_name,name,region_code,region_name,version) VALUES (
'GEO00002','ATH','Athens International Airport','ATH','Athens','GR','Greece','El.Venizelos','EUR','Europe',5d99fbbb-5ba9-4512-9660-7a3de46642e4);
INSERT INTO rcms.geographical_area (id,airport_code,airport_name,city_code,city_name,country_code,country_name,name,region_code,region_name,version) VALUES (
'GEO00003','XXX','All','XXX','All','XXX','All','All Europe','EUR','Europe',367a0d42-4c86-4962-8837-413080de2104);
INSERT INTO rcms.geographical_area (id,airport_code,airport_name,city_code,city_name,country_code,country_name,name,region_code,region_name,version) VALUES (
'GEO00001','ATH','Athens International Airport','ATH','Athens','GR','Greece','TestGeo','EUR','Europe',a863f7a0-fa68-41b9-a510-bbbfa2d07a62);
