﻿INSERT INTO rcms.counters (id,counter,version) VALUES (
'RC',1,b040b9ad-1c1e-4025-acbc-0db7c670e9d9);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'EQ',1,43bca418-b5a0-4540-a9bc-973fb7c8aa67);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'MD',1,d6a0267c-b4d9-4cab-b5b4-869fdbc5c96e);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'BDL',1,6a3af5b2-1095-4077-b03e-97eae6540a4c);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'CL',1,c0f1cf60-426c-4c20-bb96-94ea51306a78);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'SL',1,7a904e3e-355d-4e40-a6a2-b70028b743a3);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'RL',4,460a1275-12a9-466e-b839-bccbb3cf955a);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'GEO',1,c9789af8-6261-48f8-810b-bfbc9d3b04f2);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'FBC',1,b90a36c7-5bea-4024-a596-6ed41f7c67b0);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'RS',6,a2cedb43-4f6c-4092-99e3-05b1c70237bc);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'PO',2,865d7c5d-662b-4ac5-9e3e-80b2aaab1aff);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'ERR',18,7422f612-484d-4cc8-b1b1-9d3531c76477);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'SVC',2,40641be1-dcd7-45ad-8ffa-248cdf15c63c);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'FL',1,2a4a3328-f568-4395-a0ff-93ad8cbb0224);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'POS',1,6cbfb91b-f725-4d25-b0d7-0d2790046d66);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'FG',2,bfc4e4ea-6de7-4892-acfb-2ead9aaa5177);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'UR',5,2f611d4b-e7ff-4552-9ee9-dfd87b02541f);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'FFP',1,dfde65c4-9116-4f0f-a18d-e2f4dba0bf8a);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'SC',1,7026c901-a3de-4524-a789-95f24fd8b039);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'RBD',4,f71ae963-b083-4fb0-8c6a-cc08c7a7e3ac);
INSERT INTO rcms.counters (id,counter,version) VALUES (
'AL',1,dd51dca9-4303-42c3-8902-417bedb604c6);
