﻿INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'403','FL00043','AUA','CUR',8c4e45f7-6e20-4c07-817f-a950a205c09d);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'7I310','FL00039','CUR','BON',67ce0edf-53b0-4028-941d-b4478f0ed36f);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH256','FL00089','HND','FUK',799359ba-39ea-4768-aba6-d2fc8aaa3036);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3840','FL00078','HND','FUK',444be4a3-e597-4527-b59e-2442be0fe9a0);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH270','FL00099','HND','FUK',4cba1a3f-d6d4-4aac-b1d1-ae10eb9be108);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH257','FL00065','FUK','HND',fd9a120b-0950-4889-bd79-f656a6850240);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'408','FL00050','CUR','AUA',c5373aa5-2777-421b-b0e5-4df7f52cc0d2);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH264','FL00095','HND','FUK',ad867789-815b-4e71-845d-6ee34accfcc2);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'416','FL00048','CUR','AUA',fc4b9867-9bce-4f57-8f4f-1604500b6616);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH268','FL00098','HND','FUK',d3fb3ed6-91b3-43d5-911c-d576fba58b0e);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH244','FL00080','HND','FUK',86a961d3-c2af-4f4e-bc8d-2229defd8a7b);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH273','FL00075','FUK','HND',7be634c5-fec2-4159-9269-22cce15a46d5);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3842','FL00081','HND','FUK',12960d8e-2023-4308-b2fd-a3fc1d0931d3);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH258','FL00091','HND','FUK',cd45cce9-0b0c-43b8-9823-0feb747a5ad0);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'511','FL00045','SXM','CUR',6a4bfe98-e745-4ca4-903b-3c9abd53178b);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'402','FL00046','CUR','AUA',2fd09298-6ef7-43e6-b74d-fabfd170299c);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH260','FL00093','HND','FUK',39d7d5f5-42cb-4c85-8d38-3f7af04f6fcf);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH245','FL00055','FUK','HND',66e4ec2e-adc0-4ba0-9e1d-06cbda1b1a15);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3847','FL00061','FUK','HND',7e62ebb0-1563-442a-abae-43132eec4664);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH255','FL00064','FUK','HND',b3e160bf-ff86-4828-bdae-7448c01d7008);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH290','FL00111','FUK','CTS',79c011f9-8431-40a8-89a1-03046a6dee9a);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'A3265','FL00004','CHQ','ATH',2cf728a7-6a43-4e7c-a6ff-a5e9a5718f69);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'345','FL00112','MCO','MIA',bcaf1cd4-922b-48d8-ae34-c391e921a666);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3843','FL00056','FUK','HND',b4dd4578-bf06-4ea0-b59f-281a4321fb6c);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH69','FL00104','CTS','HND',9047167d-b04b-4540-9c63-7f03477d758d);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH241','FL00053','FUK','HND',2d8b79c9-d16f-405a-9d8d-5f1aa2e48517);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH62','FL00107','HND','CTS',43c5b523-3888-4d1a-86b6-2d0414a58ef7);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3848','FL00090','HND','FUK',85be9d1d-eec8-473e-9c41-51fb9e5074e5);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH263','FL00069','FUK','HND',e60973ce-3f98-4957-a6eb-eb19fdc4b4f1);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH246','FL00082','HND','FUK',f47b25b7-283b-46e3-8b55-359e57dbbcae);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3841','FL00052','FUK','HND',a5e685fe-12b9-44f8-9255-18fdaf55b464);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH251','FL00060','FUK','HND',3808cb26-e14f-4309-a0d1-3d2646c9e934);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH242','FL00079','HND','FUK',d16515f1-7d08-4aa5-88fd-0b000c8a27b6);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'OA119','FL00032','ATH','SKG',559fd342-f82a-4f23-9678-86f1defba980);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH79','FL00105','CTS','HND',2eacacd1-137e-4749-9337-446d3f5379bc);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH55','FL00103','CT','HND',7ed18b99-5412-42d3-a77f-726ced70bee1);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH261','FL00067','FUK','HND',a723af28-1f9e-4ad6-a27c-94414dbc15fb);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH50','FL00106','HN','CTS',ca3a39b9-127c-4e9d-80cf-d3fcebff954a);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH266','FL00096','HND','FUK',fda45481-af6a-4b1a-ada7-a7552c15719f);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3850','FL00092','HND','FUK',8019390b-cf31-4f37-996f-e50e849dee0a);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH259','FL00066','FUK','HND',1d4db00e-1e7b-4d7c-a8a6-7b1ef3dba16f);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH262','FL00094','HND','FUK',b9c9d11b-a474-4318-b0f2-68c161fe2b80);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'7I402','FL00035','CUR','AUA',0127c245-bbda-450e-ac08-38e4e1f4290a);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH274','FL00102','HND','FUK',a813f4b9-715c-4468-90bd-5ef420f98c18);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH249','FL00059','FUK','HND',f3013f78-2529-4727-a06d-d4b2b70bafae);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH267','FL00071','FUK','HND',cc0f10ba-ca8b-4fd8-9029-7575ae6a95a9);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH74','FL00109','HND','CTS',cd0519f5-3a60-4165-bc04-0a73130f8a44);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3852','FL00097','HND','FUK',084719ea-0bd0-45f6-bdf8-4dd4a6b6cf2f);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH254','FL00088','HND','FUK',7a8dda11-e3ec-467e-8ffc-7218ebb6be43);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3855','FL00076','FUK','HND',f6550c74-0f85-4be3-84e9-a2713aea5948);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH72','FL00108','HND','CTS',5e6ffccc-55de-4176-9eda-ddd51b4d33e1);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH243','FL00054','FUK','HND',870dcb8b-4be5-46ca-9d4f-5d9ceadb2b18);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH289','FL00110','CTS','FUK',d8b31557-03f6-409a-86ec-01d26f84ab82);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'443','FL00047','CUR','AUA',fa83053a-5dd1-419c-830d-d2ac4c32e14b);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3846','FL00087','HND','FUK',a312651d-02f5-49c6-99a6-abcd1c94ebaa);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH248','FL00083','HND','FUK',6bd9f1c7-2060-4a4d-a7b0-02d94803e2f5);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'7I305','FL00041','BON','CUR',404f1425-0e86-43ca-8ff5-b03e1e94330c);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3854','FL00101','HND','FUK',69bcc77e-7dbb-4c72-9eef-fde1b40d4b3e);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'7I301','FL00040','BON','CUR',6ee5250a-0493-4d8c-9131-6c4ed79e91a3);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH250','FL00084','HND','FUK',3e498171-961e-4189-8a7f-ba83efff1947);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3851','FL00068','FUK','HND',375b82f9-a9c9-4c97-b3b0-c835f6f3e3da);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3853','FL00072','FUK','HND',dfc9a2db-2fa9-4662-acd4-aa3e527ad8f6);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'7I404','FL00036','CUR','AUA',e00447d3-f0da-4ce4-8120-01bde5ff5fe0);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH239','FL00051','FUK','HND',af1e4775-bed0-46a9-ad09-d01095659f59);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3849','FL00063','FUK','HND',c04d9aab-bf21-47db-9451-0753ba647764);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH253','FL00062','FUK','HND',fcbdba3c-78a1-40e2-94df-a6e68ef7e922);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH269','FL00073','FUK','HND',49d77747-d77b-419e-95e9-37bd6761979b);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3844','FL00085','HND','FUK',61c47868-0676-4fa9-b807-debfbff07c3e);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH247','FL00057','FUK','HND',c01ee9c0-b625-45f9-8707-169c6f282a2f);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH3845','FL00058','FUK','HND',2a529ccd-6eee-4a64-9089-7476f83302c5);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH265','FL00070','FUK','HND',e8287f73-6626-4620-8b09-5380f75398cb);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH252','FL00086','HND','FUK',2ebadf9c-0398-4bad-8e3a-b57db7c18b41);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'7I302','FL00037','CUR','BON',447952b4-3122-41bb-994f-5fedd244e0e3);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'401','FL00042','AUA','CUR',a5066a99-8dd4-4e8f-9f96-ab565ea2d159);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'7I304','FL00038','CUR','BON',09852711-0d16-4d81-88c0-2392aa56a355);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH272','FL00100','HND','FUK',a936a86f-f35b-4f26-9432-e94a3a6942fe);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH271','FL00074','FUK','HND',41757d50-abbb-4ddb-b2c3-415d1bbe8947);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'161','FL00049','CUR','AUA',1d457229-8919-4853-abbe-2c627deb0898);
INSERT INTO rcms.flights_by_name (name,flight_id,destination,origin,version) VALUES (
'NH240','FL00077','HND','FUK',45a079ef-f279-4266-a72d-706d7bd7bfb8);
