﻿INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'CTS','New Chitose Airport','SPK','Sapporo','JP','Japan','AS','Asia',NULL,656dd300-afe7-48b5-8478-888d009881a7);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'FCO','Fiumicino International','RM','Rome','IT','Italy','EU','Europe',NULL,f9d7083b-c67d-4dcb-b1b0-c21a3a8605d0);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'HND','Haneda Airport - Tokyo International Airport','TYO','Tokyo','JP','Japan','AS','Asia',NULL,28612ef3-c519-4bbc-8c6a-11c407ad5dfb);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'CHQ','I. Daskalogiannis','CHQ','Chania','GR','Greece','EU','Europe',NULL,48864625-0e87-40a0-96a8-f7c5003d222b);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'AUA','Aruba','AU','Aruba','AU','Aruba','CR','Caribbean',NULL,645d91de-c568-4d6d-9491-972be1bc47a0);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'MCO','Orlando','MCO','Orlando','US','United States of America','FL','Florida',NULL,c884d8fe-e73f-4387-84dd-c3fc13bfcfa8);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'ATH','Eleftherios Venizelos','ATH','Athens','GR','Greece','EU','Europe',NULL,e810c3bd-bc70-473c-b90c-dd0795f411ed);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'FRA','Frankfurt Airport','FRA','Frankfurt','GE','Germany','EU','Europe',NULL,13a0ae81-b844-4a9c-a8bf-a4391a3dab99);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'BON','Bonaire','BA','Bonaire','BA','Bonaire','CR','Caribbean',NULL,6582446f-9e82-4717-a8da-5caa5d27fc9b);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'CUR','Curacao','CU','Curacao','CU','Curacao','CR','Caribbean',NULL,1bcfe134-720b-422e-950b-71f52c662f36);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'MIA','Miami International Airport','MIA','Miami','US','United States of America','FL','Florida',NULL,a8d97c16-7765-4f4a-951c-54ec4a651394);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'SXM','Saint Maarten','SM','Saint Maarten','SM','Saint Maarten','CR','Caribbean',NULL,8e0d32e4-5ca5-4d36-9084-f7a2833c82df);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'CDG','Charles de Gaulle Airport','PAR','Paris','FR','France','EU','Europe',NULL,6629fbd3-11f8-4798-8af6-f3ef25672321);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'FUK','Fukuoka Airport','FUK','Fukuoka','JP','Japan','AS','Asia',NULL,60e34db4-b2fd-4c19-a0c9-00f64cdb6b16);
INSERT INTO rcms.airport (airport_code,airport_name,city_code,city_name,country_code,country_name,region_code,region_name,solr_query,version) VALUES (
'THR','Mehrabad International Airport','THR','Tehran','IR','IRAN','MIDEAST','Middle East',NULL,f361e787-680f-4f30-ad0c-4949e339e366);
