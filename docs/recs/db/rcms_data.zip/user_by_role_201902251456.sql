﻿INSERT INTO rcms.user_by_role ("role",id,created_at,email,firstname,"language",lastname,password,phone,photo_url,rolename,status,version) VALUES (
'RL00002','UR00002',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Anonymous',NULL,NULL);
INSERT INTO rcms.user_by_role ("role",id,created_at,email,firstname,"language",lastname,password,phone,photo_url,rolename,status,version) VALUES (
'RL00002','UR00004',2019-02-06 13:17:57.522,'user@jrtechnologies.com','User','en','User','$2a$10$VEjxo0jq2YG9Rbk2HmX9S.k1uZBGYUHdUcid3g/vfiEl7lwWgOH/K','',NULL,NULL,'active',NULL);
INSERT INTO rcms.user_by_role ("role",id,created_at,email,firstname,"language",lastname,password,phone,photo_url,rolename,status,version) VALUES (
'RL00003','UR00002',2019-02-06 13:17:57.448,'anonymous@jrtechnologies.com','Anonymous','en','Anonymous','$2a$10$j8S5d7Sr7.8VTOYNviDPOeWX8KcYILUVJBsYV83Y5NtECayypx9lO','',NULL,NULL,'active',NULL);
INSERT INTO rcms.user_by_role ("role",id,created_at,email,firstname,"language",lastname,password,phone,photo_url,rolename,status,version) VALUES (
'RL00003','UR00004',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'User',NULL,NULL);
INSERT INTO rcms.user_by_role ("role",id,created_at,email,firstname,"language",lastname,password,phone,photo_url,rolename,status,version) VALUES (
'RL00001','UR00001',2019-02-06 13:17:57.401,'system@jrtechnologies.com','System','en','System','$2a$10$mE.qmcV0mFU5NcKh73TZx.z4ueI/.bDWbj0T1BYyqP481kGGarKLG','',NULL,'Administrator','active',NULL);
INSERT INTO rcms.user_by_role ("role",id,created_at,email,firstname,"language",lastname,password,phone,photo_url,rolename,status,version) VALUES (
'RL00001','UR00003',2019-02-06 13:17:57.488,'admin@jrtechnologies.com','Administrator','en','Administrator','$2a$10$gSAhZrxMllrbgj/kkK9UceBPpChGWJA7SYIb1Mqo.n5aNLq1/oRrC','',NULL,'Administrator','active',NULL);
