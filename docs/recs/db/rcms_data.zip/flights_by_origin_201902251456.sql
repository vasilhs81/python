﻿INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'CTS','FL00106','HN','NH50',ca3a39b9-127c-4e9d-80cf-d3fcebff954a);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'CTS','FL00107','HND','NH62',43c5b523-3888-4d1a-86b6-2d0414a58ef7);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'CTS','FL00108','HND','NH72',5e6ffccc-55de-4176-9eda-ddd51b4d33e1);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'CTS','FL00109','HND','NH74',cd0519f5-3a60-4165-bc04-0a73130f8a44);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'CTS','FL00111','FUK','NH290',79c011f9-8431-40a8-89a1-03046a6dee9a);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'SKG','FL00032','ATH','OA119',559fd342-f82a-4f23-9678-86f1defba980);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00051','FUK','NH239',af1e4775-bed0-46a9-ad09-d01095659f59);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00052','FUK','NH3841',a5e685fe-12b9-44f8-9255-18fdaf55b464);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00053','FUK','NH241',2d8b79c9-d16f-405a-9d8d-5f1aa2e48517);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00054','FUK','NH243',870dcb8b-4be5-46ca-9d4f-5d9ceadb2b18);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00055','FUK','NH245',66e4ec2e-adc0-4ba0-9e1d-06cbda1b1a15);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00056','FUK','NH3843',b4dd4578-bf06-4ea0-b59f-281a4321fb6c);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00057','FUK','NH247',c01ee9c0-b625-45f9-8707-169c6f282a2f);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00058','FUK','NH3845',2a529ccd-6eee-4a64-9089-7476f83302c5);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00059','FUK','NH249',f3013f78-2529-4727-a06d-d4b2b70bafae);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00060','FUK','NH251',3808cb26-e14f-4309-a0d1-3d2646c9e934);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00061','FUK','NH3847',7e62ebb0-1563-442a-abae-43132eec4664);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00062','FUK','NH253',fcbdba3c-78a1-40e2-94df-a6e68ef7e922);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00063','FUK','NH3849',c04d9aab-bf21-47db-9451-0753ba647764);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00064','FUK','NH255',b3e160bf-ff86-4828-bdae-7448c01d7008);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00065','FUK','NH257',fd9a120b-0950-4889-bd79-f656a6850240);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00066','FUK','NH259',1d4db00e-1e7b-4d7c-a8a6-7b1ef3dba16f);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00067','FUK','NH261',a723af28-1f9e-4ad6-a27c-94414dbc15fb);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00068','FUK','NH3851',375b82f9-a9c9-4c97-b3b0-c835f6f3e3da);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00069','FUK','NH263',e60973ce-3f98-4957-a6eb-eb19fdc4b4f1);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00070','FUK','NH265',e8287f73-6626-4620-8b09-5380f75398cb);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00071','FUK','NH267',cc0f10ba-ca8b-4fd8-9029-7575ae6a95a9);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00072','FUK','NH3853',dfc9a2db-2fa9-4662-acd4-aa3e527ad8f6);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00073','FUK','NH269',49d77747-d77b-419e-95e9-37bd6761979b);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00074','FUK','NH271',41757d50-abbb-4ddb-b2c3-415d1bbe8947);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00075','FUK','NH273',7be634c5-fec2-4159-9269-22cce15a46d5);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00076','FUK','NH3855',f6550c74-0f85-4be3-84e9-a2713aea5948);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00103','CT','NH55',7ed18b99-5412-42d3-a77f-726ced70bee1);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00104','CTS','NH69',9047167d-b04b-4540-9c63-7f03477d758d);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'HND','FL00105','CTS','NH79',2eacacd1-137e-4749-9337-446d3f5379bc);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'AUA','FL00035','CUR','7I402',0127c245-bbda-450e-ac08-38e4e1f4290a);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'AUA','FL00036','CUR','7I404',e00447d3-f0da-4ce4-8120-01bde5ff5fe0);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'AUA','FL00046','CUR','402',2fd09298-6ef7-43e6-b74d-fabfd170299c);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'AUA','FL00047','CUR','443',fa83053a-5dd1-419c-830d-d2ac4c32e14b);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'AUA','FL00048','CUR','416',fc4b9867-9bce-4f57-8f4f-1604500b6616);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'AUA','FL00049','CUR','161',1d457229-8919-4853-abbe-2c627deb0898);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'AUA','FL00050','CUR','408',c5373aa5-2777-421b-b0e5-4df7f52cc0d2);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'ATH','FL00004','CHQ','A3265',2cf728a7-6a43-4e7c-a6ff-a5e9a5718f69);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'BON','FL00037','CUR','7I302',447952b4-3122-41bb-994f-5fedd244e0e3);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'BON','FL00038','CUR','7I304',09852711-0d16-4d81-88c0-2392aa56a355);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'BON','FL00039','CUR','7I310',67ce0edf-53b0-4028-941d-b4478f0ed36f);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'CUR','FL00040','BON','7I301',6ee5250a-0493-4d8c-9131-6c4ed79e91a3);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'CUR','FL00041','BON','7I305',404f1425-0e86-43ca-8ff5-b03e1e94330c);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'CUR','FL00042','AUA','401',a5066a99-8dd4-4e8f-9f96-ab565ea2d159);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'CUR','FL00043','AUA','403',8c4e45f7-6e20-4c07-817f-a950a205c09d);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'CUR','FL00045','SXM','511',6a4bfe98-e745-4ca4-903b-3c9abd53178b);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'MIA','FL00112','MCO','345',bcaf1cd4-922b-48d8-ae34-c391e921a666);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00077','HND','NH240',45a079ef-f279-4266-a72d-706d7bd7bfb8);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00078','HND','NH3840',444be4a3-e597-4527-b59e-2442be0fe9a0);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00079','HND','NH242',d16515f1-7d08-4aa5-88fd-0b000c8a27b6);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00080','HND','NH244',86a961d3-c2af-4f4e-bc8d-2229defd8a7b);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00081','HND','NH3842',12960d8e-2023-4308-b2fd-a3fc1d0931d3);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00082','HND','NH246',f47b25b7-283b-46e3-8b55-359e57dbbcae);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00083','HND','NH248',6bd9f1c7-2060-4a4d-a7b0-02d94803e2f5);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00084','HND','NH250',3e498171-961e-4189-8a7f-ba83efff1947);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00085','HND','NH3844',61c47868-0676-4fa9-b807-debfbff07c3e);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00086','HND','NH252',2ebadf9c-0398-4bad-8e3a-b57db7c18b41);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00087','HND','NH3846',a312651d-02f5-49c6-99a6-abcd1c94ebaa);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00088','HND','NH254',7a8dda11-e3ec-467e-8ffc-7218ebb6be43);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00089','HND','NH256',799359ba-39ea-4768-aba6-d2fc8aaa3036);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00090','HND','NH3848',85be9d1d-eec8-473e-9c41-51fb9e5074e5);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00091','HND','NH258',cd45cce9-0b0c-43b8-9823-0feb747a5ad0);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00092','HND','NH3850',8019390b-cf31-4f37-996f-e50e849dee0a);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00093','HND','NH260',39d7d5f5-42cb-4c85-8d38-3f7af04f6fcf);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00094','HND','NH262',b9c9d11b-a474-4318-b0f2-68c161fe2b80);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00095','HND','NH264',ad867789-815b-4e71-845d-6ee34accfcc2);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00096','HND','NH266',fda45481-af6a-4b1a-ada7-a7552c15719f);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00097','HND','NH3852',084719ea-0bd0-45f6-bdf8-4dd4a6b6cf2f);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00098','HND','NH268',d3fb3ed6-91b3-43d5-911c-d576fba58b0e);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00099','HND','NH270',4cba1a3f-d6d4-4aac-b1d1-ae10eb9be108);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00100','HND','NH272',a936a86f-f35b-4f26-9432-e94a3a6942fe);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00101','HND','NH3854',69bcc77e-7dbb-4c72-9eef-fde1b40d4b3e);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00102','HND','NH274',a813f4b9-715c-4468-90bd-5ef420f98c18);
INSERT INTO rcms.flights_by_origin (origin,flight_id,destination,name,version) VALUES (
'FUK','FL00110','CTS','NH289',d8b31557-03f6-409a-86ec-01d26f84ab82);
