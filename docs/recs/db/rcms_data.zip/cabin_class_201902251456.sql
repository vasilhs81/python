﻿INSERT INTO rcms.cabin_class (name,code,cabin_class_id,version) VALUES (
'First Class','A','CL00002',64132d8c-e0a6-47f7-968a-7cd03a17e6d4);
INSERT INTO rcms.cabin_class (name,code,cabin_class_id,version) VALUES (
'Economy','H','CL00011',24825aa8-211c-449c-902a-5c807c627924);
INSERT INTO rcms.cabin_class (name,code,cabin_class_id,version) VALUES (
'Economy','L','CL00010',08f2fc56-17ca-423a-bc8e-bd423ad01bc8);
INSERT INTO rcms.cabin_class (name,code,cabin_class_id,version) VALUES (
'Economy Flexible','Y','CL00009',0ddb020d-93da-47f9-b8ab-521635bc2847);
INSERT INTO rcms.cabin_class (name,code,cabin_class_id,version) VALUES (
'Premium Economy','F','CL00005',cda0d72e-f880-4eec-84ca-d977027c4d75);
INSERT INTO rcms.cabin_class (name,code,cabin_class_id,version) VALUES (
'Economy Class','M','CL00004',85a7beb0-16f6-4df8-b566-e1ae05c9f4d6);
INSERT INTO rcms.cabin_class (name,code,cabin_class_id,version) VALUES (
'Business Class','C','CL00003',e9362041-d879-41fe-aa3a-67547627dfcc);
