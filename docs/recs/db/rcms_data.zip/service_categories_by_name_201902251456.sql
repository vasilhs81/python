﻿INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Communication','SC10112','CM',02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Internet Connection','SC00123','IC',75dbdd07-238f-4baa-98e5-3994f971bbfb);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Meal Beverage','SC00111','MLS',580c0b10-5428-4911-8d11-ebeb8cedee93);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'asd','SC00085','asd',84df7b6c-804e-4afd-8f9a-b32198b1f57e);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'asd','SC00114','asd',b11b2ab4-f601-438f-a216-fb0ab4f9e53a);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Meal','SC10111','ML',dbaa3123-fadb-4edb-a885-6d1c546e73b3);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Ground Transportation','SC00039','GT',02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Lounge','SC00040','LG',02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Fourth Bag','SC00109','BG4',e7a104e9-29f9-4cf3-b08a-81168b1737e9);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Seat Extra Legroom','SC00110','SEAT',1e19b35b-7018-486b-97ea-32d7ed853dc9);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Inflight Entertainment','SC10110','IE',d97c987e-a0ad-420f-b04e-27612b982e17);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Pets','SC00041','PT',02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00077','XX',4c795ecc-f1c9-4275-be16-94c056524e8c);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00081','XX',32859027-95ef-4f09-b44a-ac6dcb32b95f);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00083','XX',a74b0b18-f3de-4339-a916-5dbba83a98dc);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00084','XX',6748b169-209c-49e5-a4b3-4da62b136e4b);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00091','XX',46e9b436-5395-4008-87ce-9b619ff85349);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00092','XX',2e9610f4-b80a-4084-9f42-5b7b7ab563ca);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00093','XX',febbcbc0-a6d1-4492-ac07-8237f6dd6260);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00095','XX',8ebf55b5-e8b6-4438-bd33-3554524342c4);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00097','XX',c5b38443-fbbf-49a0-a49c-1da1ad29569e);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00098','XX',fbf0d8ff-2573-4d34-81db-2e13c444f102);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'XXXXX','SC00099','XX',dbfce206-fe38-446e-bdf4-148229d58bd9);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'SeaT','SC00110','SEAT',5c1bd966-0211-4deb-aa55-eb48c503e279);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Baggage','SC10109','BG',02d6b94d-0852-400b-a883-c6fe05d38ee5);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Secong Bag','SC00107','BG2',50658065-8205-4780-8dae-98f708f66249);
INSERT INTO rcms.service_categories_by_name (name,id,code,version) VALUES (
'Seat','SC00106','ST',3106aef9-6dc6-49e5-b184-87f15cb5ec48);
