﻿INSERT INTO rcms.user_by_email (email,created_at,firstname,id,"language",lastname,password,phone,photo_url,"role",rolename,status,version) VALUES (
'anonymous@jrtechnologies.com',2019-02-06 13:17:57.444,'Anonymous','UR00002','en','Anonymous','$2a$10$j8S5d7Sr7.8VTOYNviDPOeWX8KcYILUVJBsYV83Y5NtECayypx9lO',NULL,NULL,'RL00003','Anonymous','active',NULL);
INSERT INTO rcms.user_by_email (email,created_at,firstname,id,"language",lastname,password,phone,photo_url,"role",rolename,status,version) VALUES (
'user@jrtechnologies.com',2019-02-06 13:17:57.513,'User','UR00004','en','User','$2a$10$VEjxo0jq2YG9Rbk2HmX9S.k1uZBGYUHdUcid3g/vfiEl7lwWgOH/K',NULL,NULL,'RL00002','User','active',NULL);
INSERT INTO rcms.user_by_email (email,created_at,firstname,id,"language",lastname,password,phone,photo_url,"role",rolename,status,version) VALUES (
'system@jrtechnologies.com',2019-02-06 13:17:57.387,'System','UR00001','en','System','$2a$10$mE.qmcV0mFU5NcKh73TZx.z4ueI/.bDWbj0T1BYyqP481kGGarKLG',NULL,NULL,'RL00001','Administrator','active',NULL);
INSERT INTO rcms.user_by_email (email,created_at,firstname,id,"language",lastname,password,phone,photo_url,"role",rolename,status,version) VALUES (
'admin@jrtechnologies.com',2019-02-06 13:17:57.480,'Administrator','UR00003','en','Administrator','$2a$10$gSAhZrxMllrbgj/kkK9UceBPpChGWJA7SYIb1Mqo.n5aNLq1/oRrC',NULL,NULL,'RL00001','Administrator','active',NULL);
