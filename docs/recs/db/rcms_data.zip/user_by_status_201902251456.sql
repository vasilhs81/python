﻿INSERT INTO rcms.user_by_status (status,id,created_at,email,firstname,"language",lastname,password,phone,photo_url,"role",rolename,version) VALUES (
'active','UR00001',2019-02-06 13:17:57.374,'system@jrtechnologies.com','System','en','System','$2a$10$mE.qmcV0mFU5NcKh73TZx.z4ueI/.bDWbj0T1BYyqP481kGGarKLG',NULL,NULL,'RL00001','Administrator',NULL);
INSERT INTO rcms.user_by_status (status,id,created_at,email,firstname,"language",lastname,password,phone,photo_url,"role",rolename,version) VALUES (
'active','UR00002',2019-02-06 13:17:57.426,'anonymous@jrtechnologies.com','Anonymous','en','Anonymous','$2a$10$j8S5d7Sr7.8VTOYNviDPOeWX8KcYILUVJBsYV83Y5NtECayypx9lO',NULL,NULL,'RL00003','Anonymous',NULL);
INSERT INTO rcms.user_by_status (status,id,created_at,email,firstname,"language",lastname,password,phone,photo_url,"role",rolename,version) VALUES (
'active','UR00003',2019-02-06 13:17:57.471,'admin@jrtechnologies.com','Administrator','en','Administrator','$2a$10$gSAhZrxMllrbgj/kkK9UceBPpChGWJA7SYIb1Mqo.n5aNLq1/oRrC',NULL,NULL,'RL00001','Administrator',NULL);
INSERT INTO rcms.user_by_status (status,id,created_at,email,firstname,"language",lastname,password,phone,photo_url,"role",rolename,version) VALUES (
'active','UR00004',2019-02-06 13:17:57.504,'user@jrtechnologies.com','User','en','User','$2a$10$VEjxo0jq2YG9Rbk2HmX9S.k1uZBGYUHdUcid3g/vfiEl7lwWgOH/K',NULL,NULL,'RL00002','User',NULL);
