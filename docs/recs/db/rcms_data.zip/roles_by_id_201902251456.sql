﻿INSERT INTO rcms.roles_by_id (role_id,locked,role_name,version) VALUES (
'RL00002',false,'User',389fcd64-0a5e-46a4-8215-7ed426a96726);
INSERT INTO rcms.roles_by_id (role_id,locked,role_name,version) VALUES (
'RL00003',false,'Anonymous',fb392c9c-79fe-444f-b972-68517e368eb6);
INSERT INTO rcms.roles_by_id (role_id,locked,role_name,version) VALUES (
'RL00001',false,'Administrator',8cb2d9c9-2d1a-4aa8-b4ad-71e12cc5d7c7);
