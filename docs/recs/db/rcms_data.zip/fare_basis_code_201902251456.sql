﻿INSERT INTO rcms.fare_basis_code (code,id,version) VALUES (
'ARCNA6','FBC00001',7c821054-2d74-4857-8235-f977e1d4ebea);
INSERT INTO rcms.fare_basis_code (code,id,version) VALUES (
'IRCNA1','FBC00002',a1533721-ff32-4d33-91ff-054397062e98);
INSERT INTO rcms.fare_basis_code (code,id,version) VALUES (
'KCN','FBC00009',436313c8-0ec1-47e8-8abc-a083ca7a92cb);
INSERT INTO rcms.fare_basis_code (code,id,version) VALUES (
'KCP','FBC00010',45beac28-86fd-4f91-88e5-fd6b886e2b18);
