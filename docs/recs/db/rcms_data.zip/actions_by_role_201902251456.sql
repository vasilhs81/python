﻿INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','AUDIT_LOG','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','AUDIT_LOG','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','AUDIT_LOG','READ','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','AUDIT_LOG','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','BUNDLES','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','BUNDLES','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','BUNDLES','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','BUNDLES','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','CONFIGURATION','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','CONFIGURATION','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','CONFIGURATION','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','CONFIGURATION','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','CONTENT','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','CONTENT','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','CONTENT','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','CONTENT','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','DISCOUNTS','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','DISCOUNTS','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','DISCOUNTS','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','DISCOUNTS','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','ERROR_LOG','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','ERROR_LOG','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','ERROR_LOG','READ','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','ERROR_LOG','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','FLIGHTS','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','FLIGHTS','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','FLIGHTS','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','FLIGHTS','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','FLIGHT_GROUPS','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','FLIGHT_GROUPS','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','FLIGHT_GROUPS','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','FLIGHT_GROUPS','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','MARKETING_MESSAGES','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','MARKETING_MESSAGES','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','MARKETING_MESSAGES','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','MARKETING_MESSAGES','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','MEDIA_LIBRARY','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','MEDIA_LIBRARY','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','MEDIA_LIBRARY','READ','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','MEDIA_LIBRARY','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','POINTS_OF_SALE','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','POINTS_OF_SALE','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','POINTS_OF_SALE','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','POINTS_OF_SALE','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','PRICE_OPTIMIZATIONS','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','PRICE_OPTIMIZATIONS','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','PRICE_OPTIMIZATIONS','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','PRICE_OPTIMIZATIONS','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','RICH_CONTENT','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','RICH_CONTENT','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','RICH_CONTENT','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','RICH_CONTENT','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','RULE_SETS','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','RULE_SETS','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','RULE_SETS','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','RULE_SETS','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICES','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICES','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICES','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICES','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICE_CATEGORIES','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICE_CATEGORIES','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICE_CATEGORIES','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICE_CATEGORIES','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICE_PACKS','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICE_PACKS','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICE_PACKS','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','SERVICE_PACKS','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','USERS','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','USERS','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','USERS','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','USERS','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','USER_ROLES','CREATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','USER_ROLES','DELETE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','USER_ROLES','READ','User',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00002','USER_ROLES','UPDATE','User',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','AUDIT_LOG','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','AUDIT_LOG','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','AUDIT_LOG','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','AUDIT_LOG','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','BUNDLES','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','BUNDLES','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','BUNDLES','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','BUNDLES','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','CONFIGURATION','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','CONFIGURATION','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','CONFIGURATION','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','CONFIGURATION','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','CONTENT','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','CONTENT','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','CONTENT','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','CONTENT','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','DISCOUNTS','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','DISCOUNTS','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','DISCOUNTS','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','DISCOUNTS','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','ERROR_LOG','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','ERROR_LOG','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','ERROR_LOG','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','ERROR_LOG','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','FLIGHTS','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','FLIGHTS','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','FLIGHTS','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','FLIGHTS','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','FLIGHT_GROUPS','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','FLIGHT_GROUPS','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','FLIGHT_GROUPS','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','FLIGHT_GROUPS','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','MARKETING_MESSAGES','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','MARKETING_MESSAGES','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','MARKETING_MESSAGES','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','MARKETING_MESSAGES','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','MEDIA_LIBRARY','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','MEDIA_LIBRARY','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','MEDIA_LIBRARY','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','MEDIA_LIBRARY','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','POINTS_OF_SALE','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','POINTS_OF_SALE','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','POINTS_OF_SALE','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','POINTS_OF_SALE','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','PRICE_OPTIMIZATIONS','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','PRICE_OPTIMIZATIONS','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','PRICE_OPTIMIZATIONS','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','PRICE_OPTIMIZATIONS','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','RICH_CONTENT','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','RICH_CONTENT','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','RICH_CONTENT','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','RICH_CONTENT','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','RULE_SETS','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','RULE_SETS','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','RULE_SETS','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','RULE_SETS','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICES','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICES','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICES','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICES','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICE_CATEGORIES','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICE_CATEGORIES','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICE_CATEGORIES','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICE_CATEGORIES','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICE_PACKS','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICE_PACKS','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICE_PACKS','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','SERVICE_PACKS','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','USERS','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','USERS','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','USERS','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','USERS','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','USER_ROLES','CREATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','USER_ROLES','DELETE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','USER_ROLES','READ','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00003','USER_ROLES','UPDATE','Anonymous',false);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','AUDIT_LOG','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','AUDIT_LOG','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','AUDIT_LOG','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','AUDIT_LOG','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','BUNDLES','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','BUNDLES','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','BUNDLES','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','BUNDLES','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','CONFIGURATION','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','CONFIGURATION','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','CONFIGURATION','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','CONFIGURATION','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','CONTENT','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','CONTENT','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','CONTENT','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','CONTENT','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','DISCOUNTS','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','DISCOUNTS','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','DISCOUNTS','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','DISCOUNTS','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','ERROR_LOG','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','ERROR_LOG','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','ERROR_LOG','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','ERROR_LOG','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','FLIGHTS','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','FLIGHTS','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','FLIGHTS','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','FLIGHTS','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','FLIGHT_GROUPS','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','FLIGHT_GROUPS','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','FLIGHT_GROUPS','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','FLIGHT_GROUPS','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','MARKETING_MESSAGES','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','MARKETING_MESSAGES','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','MARKETING_MESSAGES','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','MARKETING_MESSAGES','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','MEDIA_LIBRARY','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','MEDIA_LIBRARY','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','MEDIA_LIBRARY','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','MEDIA_LIBRARY','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','POINTS_OF_SALE','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','POINTS_OF_SALE','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','POINTS_OF_SALE','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','POINTS_OF_SALE','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','PRICE_OPTIMIZATIONS','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','PRICE_OPTIMIZATIONS','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','PRICE_OPTIMIZATIONS','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','PRICE_OPTIMIZATIONS','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','RICH_CONTENT','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','RICH_CONTENT','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','RICH_CONTENT','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','RICH_CONTENT','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','RULE_SETS','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','RULE_SETS','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','RULE_SETS','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','RULE_SETS','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICES','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICES','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICES','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICES','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICE_CATEGORIES','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICE_CATEGORIES','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICE_CATEGORIES','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICE_CATEGORIES','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICE_PACKS','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICE_PACKS','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICE_PACKS','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','SERVICE_PACKS','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','USERS','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','USERS','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','USERS','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','USERS','UPDATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','USER_ROLES','CREATE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','USER_ROLES','DELETE','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','USER_ROLES','READ','Administrator',true);
INSERT INTO rcms.actions_by_role (role_id,module_name,action_name,role_name,active) VALUES (
'RL00001','USER_ROLES','UPDATE','Administrator',true);
