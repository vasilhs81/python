﻿INSERT INTO rcms.entity_dependency (parent_id,child_id,child_name,parent_name,version) VALUES (
'RS00004','PO00001','PO','RS',ff238a97-9773-4d65-9b81-8cc44e1060fc);
