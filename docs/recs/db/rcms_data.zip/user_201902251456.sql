﻿INSERT INTO rcms."user" (id,created_at,email,firstname,"language",lastname,password,phone,photo_url,reset_date,reset_key,"role",rolename,status,version) VALUES (
'UR00002',2019-02-06 13:17:57.414,'anonymous@jrtechnologies.com','Anonymous','en','Anonymous','$2a$10$j8S5d7Sr7.8VTOYNviDPOeWX8KcYILUVJBsYV83Y5NtECayypx9lO',NULL,NULL,NULL,NULL,'RL00003','Anonymous','active',NULL);
INSERT INTO rcms."user" (id,created_at,email,firstname,"language",lastname,password,phone,photo_url,reset_date,reset_key,"role",rolename,status,version) VALUES (
'UR00001',2019-02-06 13:17:57.334,'system@jrtechnologies.com','System','en','System','$2a$10$mE.qmcV0mFU5NcKh73TZx.z4ueI/.bDWbj0T1BYyqP481kGGarKLG',NULL,NULL,NULL,NULL,'RL00001','Administrator','active',NULL);
INSERT INTO rcms."user" (id,created_at,email,firstname,"language",lastname,password,phone,photo_url,reset_date,reset_key,"role",rolename,status,version) VALUES (
'UR00003',2019-02-06 13:17:57.459,'admin@jrtechnologies.com','Administrator','en','Administrator','$2a$10$gSAhZrxMllrbgj/kkK9UceBPpChGWJA7SYIb1Mqo.n5aNLq1/oRrC',NULL,NULL,NULL,NULL,'RL00001','Administrator','active',NULL);
INSERT INTO rcms."user" (id,created_at,email,firstname,"language",lastname,password,phone,photo_url,reset_date,reset_key,"role",rolename,status,version) VALUES (
'UR00004',2019-02-06 13:17:57.496,'user@jrtechnologies.com','User','en','User','$2a$10$VEjxo0jq2YG9Rbk2HmX9S.k1uZBGYUHdUcid3g/vfiEl7lwWgOH/K',NULL,NULL,NULL,NULL,'RL00002','User','active',NULL);
