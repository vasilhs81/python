﻿INSERT INTO rcms.flight_group_by_name (name,id,flight_id,destination,flight_name,origin,status,tags,version) VALUES (
'Aruba to St Maarten','FG00012','FL00035','CUR','7I402','AUA',NULL,NULL,07778bf8-6315-46bf-92cd-4eee897074b8);
INSERT INTO rcms.flight_group_by_name (name,id,flight_id,destination,flight_name,origin,status,tags,version) VALUES (
'Aruba to St Maarten','FG00012','FL00044','SXM','7I511','CUR',NULL,NULL,07778bf8-6315-46bf-92cd-4eee897074b8);
INSERT INTO rcms.flight_group_by_name (name,id,flight_id,destination,flight_name,origin,status,tags,version) VALUES (
'asd','FG00005','FL00011','ASD','ASD','ASD',NULL,NULL,40874425-53bb-4a4b-b5d4-0c60c2c891c4);
INSERT INTO rcms.flight_group_by_name (name,id,flight_id,destination,flight_name,origin,status,tags,version) VALUES (
'Test FG','FG00013','FL00049','CUR','161','AUA',NULL,[tag1],2897b4b2-915e-40b0-b615-11ab4ba56200);
INSERT INTO rcms.flight_group_by_name (name,id,flight_id,destination,flight_name,origin,status,tags,version) VALUES (
'Bill FlightGroup1 CUR-SXM','FG00001','FL00045','SXM','511','CUR',NULL,NULL,d84ef79d-e93f-47a9-8919-7850ecc70b12);
