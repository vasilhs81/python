﻿INSERT INTO rcms.reservation_booking_designator (code,id,version) VALUES (
'Q','RBD00002',12d1c9f4-b902-4ec0-8e61-13075837b180);
INSERT INTO rcms.reservation_booking_designator (code,id,version) VALUES (
'Y','RBD00001',d85d3467-d887-4186-b9ba-bced56c56518);
INSERT INTO rcms.reservation_booking_designator (code,id,version) VALUES (
'L','RBD00003',f50faf2f-954f-4644-b03b-d614fa93f186);
